package ca.utoronto.lms.auth;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(locations = "classpath:test.yaml")
class AuthServiceApplicationTests {
    @Test
    void contextLoads() {}
}
