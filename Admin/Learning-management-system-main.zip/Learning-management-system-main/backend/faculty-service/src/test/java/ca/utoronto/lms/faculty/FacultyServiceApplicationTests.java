package ca.utoronto.lms.faculty;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(locations = "classpath:test.yaml")
class FacultyServiceApplicationTests {
    @Test
    void contextLoads() {}
}
