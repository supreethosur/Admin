package ca.utoronto.lms.exam;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(locations = "classpath:test.yaml")
class ExamServiceApplicationTests {
    @Test
    void contextLoads() {}
}
