package ca.utoronto.lms.subject;

import org.junit.jupiter.api.Test;
import org.springframework.test.context.TestPropertySource;

@TestPropertySource(locations = "classpath:test.yaml")
class SubjectServiceApplicationTests {
    @Test
    void contextLoads() {}
}
