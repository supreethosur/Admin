export interface Tokens {
  accessToken: string;
  refreshToken: string;
}
