export interface Base {
  id?: number;
  [key: string]: any;
}
