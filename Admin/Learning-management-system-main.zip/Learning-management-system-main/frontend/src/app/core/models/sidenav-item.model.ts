export interface SidenavItem {
  text: string;
  link: string;
}
