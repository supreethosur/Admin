export interface PageRequest {
  search: string;
  page: number;
  size: number;
  sort?: string;
}
