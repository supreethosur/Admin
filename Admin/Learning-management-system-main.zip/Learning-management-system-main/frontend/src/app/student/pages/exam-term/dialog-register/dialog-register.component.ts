import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialog-register',
  templateUrl: './dialog-register.component.html',
  styleUrls: ['./dialog-register.component.scss']
})
export class DialogRegisterComponent implements OnInit {
  constructor() { }

  ngOnInit(): void { }
}
